#!/bin/sh

ENV=~/.bash_profile

if [[ ! -n `cat $ENV | grep '/opt/MESA/'` ]];
then
	echo "export C_INCLUDE_PATH=/opt/MESA/include/MESA/:/opt/MESA/include/:\$C_INCLUDE_PATH" >> $ENV
	echo "export CPLUS_INCLUDE_PATH=/opt/MESA/include/MESA/:/opt/MESA/include/:\$CPLUS_INCLUDE_PATH" >> $ENV

	echo "export LIBRARY_PATH=/opt/MESA/lib/:\$LIBRARY_PATH" >> $ENV
	echo "export LD_LIBRARY_PATH=/opt/MESA/lib/:\$LD_LIBRARY_PATH" >> $ENV

	source $ENV
fi

source $ENV
